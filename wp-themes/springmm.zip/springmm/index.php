<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spring_MM
 */

get_header();
?>

<!-- Hero Section -->
<?php if ( is_active_sidebar( 'hero-widget-area' ) ) : ?>
<section id="hero-widget-area" class="hero">
<?php dynamic_sidebar( 'hero-widget-area' ); ?>
</section>
<?php endif; ?>

<main id="primary" class="site-main columns is-gapless">
	<div class="column is-1"></div>

	<div class="column is-half">
		<?php if (have_posts()) : ?>
			<?php while ( have_posts() ) : the_post(); ?>
			<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
				<div class="columns is-gapless">
					<div class="column is-one-third">
					<?php the_post_thumbnail(); ?>
					</div>
					<div class="column">
						<p class="is-size-6 has-text-black-ter"> <?php the_title(); ?> </p>
						<p class="is-size-7 has-text-primary"> Posted at <?php $post_date = get_the_date( 'D M j' ); echo $post_date; ?> | Last updated at <?php the_modified_time('F jS, Y'); ?> </p>
						<p class="is-size-7 has-text-grey-dark"><?php echo springmm_excerpt(213); ?> ...</p>
					</div>
				</div>	
			</a>
			<div class="px-2 mb-2">
				<?php 
					$the_cat = get_the_category();
					$category_name = $the_cat[0]->cat_name;
					$category_link = get_category_link( $the_cat[0]->cat_ID );
				?>
				<a href="<?php echo $category_link ?>" class="button is-small is-primary is-rounded mb-1"> <?php echo $category_name ?> </a>
				<?php
					global $post;
					foreach(get_the_tags($post->ID) as $tag){
						echo '<a href="' . get_tag_link($tag->term_id) . '" class=" button is-small is-primary is-outlined is-rounded mb-1">' . $tag->name . '</a>';
					}
				?>
			</div>
			
			<?php endwhile; ?>
		<?php else : ?>
			<p> no post </p>
		<?php endif; ?>
	</div>

	<div class="column is-3 mx-2">
		<?php get_sidebar(); ?>
	</div>
	<div class="column mx-2">
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
	</div>
	<div class="column is-1"></div>
</main>

<?php
//get_sidebar();
get_footer();
