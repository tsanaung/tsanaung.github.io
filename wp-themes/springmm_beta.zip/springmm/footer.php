<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Spring_MM
 */

?>

	<footer id="colophon" class="site-footer">
		<div class="site-info has-text-centered notification">
			&copy;2021 <?php bloginfo( 'name' ); ?> | All Rights Reserved ~ 
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'Designed %1$s by %2$s.', 'springmm' ), 'SpringMM', '<a href="https://tsanaung.github.io">Tsan Aung</a>' );
				?> <a href="https://zoos.icu">ZOOS.ICU</a>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>


<!-- Bulma Navigation -->
<script>
 document.addEventListener('DOMContentLoaded', () => {
        
		// Get all "navbar-burger" elements
		const $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);
	
		// Check if there are any navbar burgers
		if ($navbarBurgers.length > 0) {
	
			// Add a click event on each of them
			$navbarBurgers.forEach( el => {
				el.addEventListener('click', () => {
	
				// Get the target from the "data-target" attribute
				const target = el.dataset.target;
				const $target = document.getElementById(target);
	
				// Toggle the "is-active" class on both the "navbar-burger" and the "navbar-menu"
				el.classList.toggle('is-active');
				$target.classList.toggle('is-active');
				});
			});
		}
	});
</script>

</body>
</html>
