<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Spring_MM
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area column is-3 mx-3">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>

<aside id="secondary" class="widget-area column mx-3">
	<?php dynamic_sidebar( 'sidebar-2' ); ?>
</aside>
