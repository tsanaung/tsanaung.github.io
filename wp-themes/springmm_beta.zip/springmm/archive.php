<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spring_MM
 */

get_header();
?>

<?php 
if ( have_posts() ) : 
	the_archive_title( '<h1 class="page-title">', '</h1>' );
	the_archive_description( '<div class="archive-description">', '</div>' );
?>

<main class="columns is-gapless"> 
	<div class="column is-1"></div>

<div class="column is-half">
<?php
	while ( have_posts() ) :
		the_post();
		get_template_part( 'template-parts/content', get_post_type() );
	endwhile;
	the_posts_navigation();

else: 
	get_template_part( 'template-parts/content', 'none' ); 
endif;
?>
</div> 

<?php get_sidebar(); ?>
</main>

<?php
get_footer();
