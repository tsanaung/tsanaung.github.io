<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Spring_MM
 */

get_header();
?>

<main id="primary" class="site-main mt-1 columns is-gapless">
	<div class="column is-1"></div>

	<div class="column is-half">
		<?php while ( have_posts() ) : the_post(); ?>
		<?php the_post_thumbnail(); ?>
		<p class="is-size-5-desktop has-text-weight-semibold mb-1"> <?php the_title(); ?> </p>
		<div class="tags has-addons m-1">
			<?php $the_cat = get_the_category(); $category_name = $the_cat[0]->cat_name; $category_link = get_category_link( $the_cat[0]->cat_ID ); ?>
			<a href="<?php echo $category_link ?>" class="tag is-primary"> <?php echo $category_name ?> </a> <span class="tag"> Updated: <?php the_modified_time('F jS, Y'); ?></span>
		</div>
		<?php the_content(); ?>
		<div class="message is-primary is-small">
		<p class="message-body is-small"> This article was originally published on <?php bloginfo('name'); ?> in <a href="<?php echo $category_link ?>" class="tag is-primary"> <?php echo $category_name ?> </a> by <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a> at <?php $post_date = get_the_date( 'D M j' ); echo $post_date; ?> and Updated at <?php the_modified_time('F jS, Y'); ?>, Tagged in <?php global $post; foreach(get_the_tags($post->ID) as $tag){echo '<a href="' . get_tag_link($tag->term_id) . '" class="tag is-dark m-1">' . $tag->name . '</a>';} ?></p> 
		</div>
		<div class="fb-like" data-href="<?php the_permalink() ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-share="true"></div>
		<?php if ( comments_open() || get_comments_number() ) : comments_template(); endif; ?> 
		<?php endwhile; ?>
	</div>

	<?php get_sidebar(); ?>

</main>


<?php
get_footer();
