<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spring_MM
 */

?>

<a href="<?php the_permalink() ?>" class="card">
	<?php springmm_post_thumbnail(); ?>
	<p class="is-size-6 has-text-black-ter"> <?php if ( is_singular() ) : the_title( '<p class="entry-title is-size-5-desktop has-text-weight-semibold mb-1">', '</p>' ); else : the_title( '<p class="entry-title is-size-5-desktop has-text-weight-semibold mb-1">', '</p>' ); endif; if ( 'post' === get_post_type() ) : endif; ?> </p>
	<p class="is-size-7 has-text-grey-dark"><?php echo springmm_excerpt(213); ?> ...</p>
</a>
<p class="is-size-7 has-text-primary"> Posted at <?php $post_date = get_the_date( 'D M j' ); echo $post_date; ?> | Last updated at <?php the_modified_time('F jS, Y'); ?> </p>
<?php global $post; foreach(get_the_tags($post->ID) as $tag){ echo '<a href="' . get_tag_link($tag->term_id) . '" class="tag">' . $tag->name . '</a>'; } ?>
