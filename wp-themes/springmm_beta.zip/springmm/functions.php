<?php
/**
 * Spring MM functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Spring_MM
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

if ( ! function_exists( 'springmm_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function springmm_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Spring MM, use a find and replace
		 * to change 'springmm' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'springmm', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'menu-1' => esc_html__( 'Primary', 'springmm' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'springmm_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'springmm_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function springmm_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'springmm_content_width', 640 );
}
add_action( 'after_setup_theme', 'springmm_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function springmm_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar 1st Column', 'springmm' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'springmm' ),
			//'before_widget' => '<section id="%1$s" class="widget %2$s column">',
			//'after_widget'  => '</section>',
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar 2nd Column', 'springmm' ),
			'id'            => 'sidebar-2',
			'description'   => esc_html__( 'Right Sidebar 2', 'springmm' ),
			//'before_widget' => '<section id="%1$s" class="widget %2$s column">',
			//'after_widget'  => '</section>',
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'springmm_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function springmm_scripts() {
	wp_enqueue_style( 'springmm-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'springmm-style', 'rtl', 'replace' );

	wp_enqueue_script( 'springmm-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'springmm_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Enqeue Bulma
 */
function springmm_bulma() {
	wp_enqueue_style('springmm-bulma', get_stylesheet_directory_uri() .'/sass/bulma.css');
	}
	add_action('wp_enqueue_scripts', 'springmm_bulma');

/**
 * Enqeue Tsan's CSS
 */
function springmm_tsan() {
	wp_enqueue_style( 'springmm-tsan', get_template_directory_uri() . '/sass/tsan.css', array(), rand(111,9999), 'all' );
	}
	add_action('wp_enqueue_scripts', 'springmm_tsan');


/**
 * Bulma NavWalker
 */
register_nav_menus( array(
    'primary' => __( 'Primary Menu', 'primary' ),
) );

/**
 * Bulma-Navwalker
 *
 * @package Bulma-Navwalker
 */

/**
 * Class Name: Navwalker
 * Plugin Name: Bulma Navwalker
 * Plugin URI:  https://github.com/Poruno/Bulma-Navwalker
 * Description: An extended Wordpress Navwalker object that displays Bulma framework's Navbar https://bulma.io/ in Wordpress.
 * Author: Carlo Operio - https://www.linkedin.com/in/carlooperio/, Bulma-Framework
 * Author URI: https://github.com/wp-bootstrap
 * License: GPL-3.0+
 * License URI: https://github.com/Poruno/Bulma-Navwalker/blob/master/LICENSE
 */

	class Navwalker extends Walker_Nav_Menu {

        public function start_lvl( &$output, $depth = 0, $args = array() ) {
           
            $output .= "<div class='navbar-dropdown'>";
        }

        public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

            $liClasses = 'navbar-item '.$item->title;

            $hasChildren = $args->walker->has_children;
            $liClasses .= $hasChildren? " has-dropdown is-hoverable": "";

            if($hasChildren){
                $output .= "<div class='".$liClasses."'>";
                $output .= "\n<a class='navbar-link' href='".$item->url."'>".$item->title."</a>";
            }
            else {
                $output .= "<a class='".$liClasses."' href='".$item->url."'>".$item->title;
            }

            // Adds has_children class to the item so end_el can determine if the current element has children
            if ( $hasChildren ) {
                $item->classes[] = 'has_children';
            }
        }
        
        public function end_el(&$output, $item, $depth = 0, $args = array(), $id = 0 ){

            if(in_array("has_children", $item->classes)) {

                $output .= "</div>";
            }
            $output .= "</a>";
        }

        public function end_lvl (&$output, $depth = 0, $args = array()) {

            $output .= "</div>";
        }
    } 

/**
 * Hero Widget
 */
function hero_widget_area() {
	register_sidebar(
	array(
	'id' => 'hero-widget-area',
	'name' => esc_html__( 'Hero Section', 'springmm-hero' ),
	'description' => esc_html__( 'This widget will display on HomePage only, should not set widget title', 'springmm-hero' ),
	//'before_widget' => '<div id="%1$s" class="widget %2$s">',
	//'after_widget' => '</div>',
	'before_widget' => '',
	'after_widget' => '',
	//'before_title' => '<div class="widget-title-holder"><h3 class="widget-title">',
	'before_title' => '',
	//'after_title' => '</h3></div>'
	'after_title' => ''
	)
	);
	}
	add_action( 'widgets_init', 'hero_widget_area' );

/**
 * limit excerpt length by character count
 */
function springmm_excerpt( $count ) {
	$permalink = get_permalink($post->ID);
	$excerpt = get_the_content();
	$excerpt = strip_tags($excerpt);
	$excerpt = substr($excerpt, 0, $count);
	$excerpt = substr($excerpt, 0, strripos($excerpt, " "));
	//$excerpt = '<p>'.$excerpt.'... <a href="'.$permalink.'">Read More</a></p>';
	return $excerpt;
	}

/**
 * Get the last updated date & time
 */
function springmm_last_updated_date( $content ) {
	$u_time = get_the_time('U'); 
	$u_modified_time = get_the_modified_time('U'); 
	if ($u_modified_time >= $u_time + 86400) { 
	$updated_date = get_the_modified_time('F jS, Y');
	$updated_time = get_the_modified_time('h:i a'); 
	$custom_content .= 'Updated on '. $updated_date . ' at '. $updated_time .'</p>';  
	} 
	 
		$custom_content .= $content;
		return $custom_content;
	}
	add_filter( 'the_content', 'springmm_last_updated_date' );

// Enqueue Font Awesome 5 in WordPress 
function tme_load_font_awesome() {
    // You can find the current URL for the latest version here: https://fontawesome.com/start
    wp_enqueue_style( 'font-awesome-free', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css' );
}
add_action( 'wp_enqueue_scripts', 'tme_load_font_awesome' );

// Numeric Pagination
function springmm_numeric_pagination($pages = '', $range = 2)
{  
     $showitems = ($range * 2)+1;  

     global $paged;
     if(empty($paged)) $paged = 1;

     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }   

     if(1 != $pages)
     {
         echo "<nav class='pagination is-small is-rounded'> <ul class='pagination-list'>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."' class='pagination-link has-background-primary'>&laquo;</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."' class='pagination-link has-background-primary'>&lsaquo;</a>";

         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class='pagination-link has-background-primary'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='pagination-link' >".$i."</a>";
             }
         }

         if ($paged < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($paged + 1)."' class='pagination-link has-background-primary'>&rsaquo;</a>";  
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."' class='pagination-link has-background-primary'>&raquo;</a>";
         echo "</ul></nav>\n";
     }
}