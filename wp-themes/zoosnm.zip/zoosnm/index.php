<?php get_header(); ?>

<div class="main">

<div class="left-sidebar hides hidem">

    <?php wp_nav_menu( array( 'theme_location' => 'main-menu' ) ); ?>

    <?php get_sidebar(); ?>
</div>

<main>







<?php if (have_posts()) : ?>

<?php while ( have_posts() ) : the_post(); ?>

<article class="postloop">
    
    <a href="<?php the_permalink() ?>" class="ftinpl">
    
        <?php the_post_thumbnail(); ?>

        <h3 class="title"><?php the_title(); ?></h3>

    </a>
        
        <p class="tsmall">Posted: <?php the_date(); ?> by <?php the_author(); ?>, <?php the_tags(); ?>, <a href="<?php comments_link(); ?>" title="Leave a comment">Comments</a> </p>

</article>        

<?php endwhile; ?>



    
<?php else : ?>
        <p>Sorry, there isn't any post yet...</p>
<?php endif; ?>



</main>



</div><!-- .main --> 

<div style="clear:both;"> </div>

    <?php get_template_part( 'nav', 'below' ); ?>



<?php get_footer(); ?>

