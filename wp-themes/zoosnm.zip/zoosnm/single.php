<?php get_header(); ?>

<div>

    <div class="left-sidebar hides hidem">
        <?php wp_nav_menu( array( 'theme_location' => 'main-menu' ) ); ?>
    </div>

    <article id="post-<?php the_ID(); ?>" class="article">
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <?php get_template_part( 'entry' ); ?>
        <?php if ( comments_open() && ! post_password_required() ) { comments_template( '', true ); } ?>
        <?php endwhile; endif; ?>
    </article>

    <div class="left-sidebar right-sidebar">
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('zoosrb') ) : 
        endif; ?>
    </div>

</div>


<?php get_footer(); ?>