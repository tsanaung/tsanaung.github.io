<article id="post-<?php the_ID(); ?>">
<?php the_post_thumbnail(); ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark">
<header><?php the_title(); ?></header>
</a>

<?php get_template_part( 'entry-footer' ); ?>

<?php the_content(); ?>

<div style="clear:both;"></div>
</article>