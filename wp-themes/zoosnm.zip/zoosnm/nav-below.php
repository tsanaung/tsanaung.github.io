<?php
/*
$args = array(
'prev_text' => sprintf( esc_html__( '%s older', 'zoosnm' ), 'posts ... &larr; ' ),
'next_text' => sprintf( esc_html__( 'newer %s', 'zoosnm' ), '&rarr; posts ...' )
);
the_posts_navigation( $args ); 
*/
?>

<div class="pagination">
    <?php zoosnm_pagination(); ?>
</div>