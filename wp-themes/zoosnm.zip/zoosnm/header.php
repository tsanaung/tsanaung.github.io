<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<?php wp_head(); ?>
</head>
<body <?php //body_class(); ?>>

<?php
if(has_custom_logo()){
    $custom_logo_id = get_theme_mod( 'custom_logo' );
    $custom_logo_data = wp_get_attachment_image_src( $custom_logo_id , 'full' );
    $custom_logo_url = $custom_logo_data[0];
}
else{
    $custom_logo_url = "https://i1.wp.com/free.zoos.icu/wp-content/uploads/2020/12/cropped-zoos_fabicon_light.png";
}
?>

<header class="nav sticky-header nubar">
    <div class="nav-logo">
        <a href="<?php echo get_bloginfo('url'); ?>">
            <img class="logo" src="<?php echo $custom_logo_url; ?>" />
        </a>
    </div>
    <div class="nav-site-name">
        <a href="<?php echo get_bloginfo('url'); ?>">
            <span class="site-title"><?php bloginfo( 'name' ); ?></span>
        </a>
    </div>
    <div class="nav-menu-icon hidel">
        <a href="#show">
            <span class="menu-icon">&#x2630;</span>
        </a>
    </div>
</header>

<div style="clear:both;"></div>

<div id="show" class="mobnav">
<a href="#hide"> <span class="menu-icon-close">&#128473;</span> </a>
<?php wp_nav_menu( array( 'theme_location' => 'main-menu' ) ); ?>
</div>

