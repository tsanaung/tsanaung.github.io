//toggle the #lmmnav
function lmmnav() {
    var element = document.getElementById("lmmnav");
    var menu = document.querySelector('.navbar-menu');
    element.classList.toggle("is-active");
    menu.classList.toggle('is-active');
}